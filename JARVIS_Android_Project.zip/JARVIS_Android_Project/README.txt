JARVIS AI — Android source project
=================================

This is a starter Android Studio/AndroidIDE project. It is source code, NOT a compiled APK.

WHAT IT DOES
- Futuristic JARVIS dashboard
- Native Android speech recognition (tap-to-talk)
- Native Android text-to-speech
- Time/date commands
- Opens YouTube, Google, WhatsApp web link
- Google web search
- Local notes stored on the device
- Opens ChatGPT for advanced AI chat

IMPORTANT LIMITATIONS
- No always-listening "Hey JARVIS" wake word.
- No unrestricted control of the phone.
- ChatGPT opens separately; there is no private API key or built-in AI API connection.
- Speech recognition availability and language depend on the Android device's installed speech service and internet connection.
- Microphone permission is requested when you tap the microphone.

BUILD NOTES
1. Transfer/extract this ZIP into a folder on your Android phone.
2. Open the extracted project in a compatible Android IDE that supports Gradle Android projects.
3. Let Gradle sync. Internet is required to download Android build tools and plugins.
4. Build the debug APK from the IDE's Build menu.
5. Install only the APK you built yourself. Android may ask you to allow installs from that IDE.
6. If build fails, share the exact error text or screenshot so the project can be adjusted.

Project settings:
- Application ID: com.example.jarvis
- Minimum Android: 6.0 (API 23)
- Compile/target SDK: 35
- Version: 1.0

This project is provided as a beginner starter. It has not been compiled or tested on your specific phone.
